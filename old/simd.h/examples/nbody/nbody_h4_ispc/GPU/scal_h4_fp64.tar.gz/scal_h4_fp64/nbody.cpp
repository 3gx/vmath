#include "../ocldev.h"

#define FTINY 1e-10
#define FHUGE 1e+10

#include <sys/time.h>
inline double get_time() {
  struct timeval Tvalue;
  struct timezone dummy;

  gettimeofday(&Tvalue,&dummy);
  return ((double) Tvalue.tv_sec +1.e-6*((double) Tvalue.tv_usec));
}

struct real4 {
  double x, y, z, w;
  real4() {};
  real4(const double &_x, 
	 const double &_y,
	 const double &_z,
	 const double &_w = 0) : x(_x), y(_y), z(_z), w(_w) {};
  const double abs2() const {return x*x + y*y + z*z;}
};

inline const double sqr(const double &x) {return x*x;}


#define BLOCKDIM 64

void forces(
    dev::kernel &forces,
    dev::memory<real4> &pos,
    dev::memory<real4> &vel,
    dev::memory<real4> &acc,
    dev::memory<real4> &jrk,
    double eps2) {
  int n = pos.size();
  forces.setWork_1D(BLOCKDIM, n);

  forces.set_arg<void* >(0, pos.ptr());
  forces.set_arg<void* >(1, vel.ptr());
  forces.set_arg<void* >(2, acc.ptr());
  forces.set_arg<void* >(3, jrk.ptr());
  forces.set_arg<double >(4, &eps2);
  forces.set_arg<int   >(5, &n);
  forces.set_arg<real4>(6, NULL, 2*BLOCKDIM);

  forces.execute();
  forces.wait();
}

const double timestep(
    dev::memory<real4> &vel,
    dev::memory<real4> &acc,
    const double eta,
    const double eps2) 
{
  double dt_min = FHUGE;
  const int n = vel.size();
  for (int i = 0; i < n; i++) {
    const double vabs = std::sqrt(vel[i].abs2());
    const double aabs = std::sqrt(acc[i].abs2());

    const double s = std::sqrt(eps2);
    const double idt1 = s/(vabs + FTINY);
    const double idt2 = std::sqrt(s/(aabs + FTINY));
    dt_min = std::min(dt_min, std::min(idt1, idt2));
  }
  dt_min *= eta;

  return dt_min;
}

void energy(
    dev::memory<real4> &pos,
    dev::memory<real4> &vel,
    dev::memory<real4> &acc,
    double &Ekin, double &Epot) {
  Ekin = Epot = 0;
  const int n = pos.size();
  for (int i = 0; i < n; i++) {
    Ekin += pos[i].w * vel[i].abs2() * 0.5;
    Epot += 0.5*pos[i].w * acc[i].w;
  }
}

const double iterate(
    dev::kernel &compute_forces,
    dev::memory<real4> &pos,
    dev::memory<real4> &vel,
    dev::memory<real4> &acc,
    dev::memory<real4> &jrk,
    const double eta,
    const double eps2,
    const double dt) 
{
  const int n = pos.size();
  std::vector<real4> acc0(n), jrk0(n);
  const double dt2 = dt*(1.0/2.0);
  const double dt3 = dt*(1.0/3.0);

  for (int i = 0; i < n; i++)
  {
    acc0[i] = acc[i];
    jrk0[i] = jrk[i];

    pos[i].x += dt*(vel[i].x + dt2*(acc[i].x + dt3*jrk[i].x));
    pos[i].y += dt*(vel[i].y + dt2*(acc[i].y + dt3*jrk[i].y));
    pos[i].z += dt*(vel[i].z + dt2*(acc[i].z + dt3*jrk[i].z));
    
    vel[i].x += dt*(acc[i].x + dt2*jrk[i].x);
    vel[i].y += dt*(acc[i].y + dt2*jrk[i].y);
    vel[i].z += dt*(acc[i].z + dt2*jrk[i].z);
  }

  vel.h2d();
  pos.h2d();

  forces(compute_forces, pos, vel, acc, jrk, eps2);

  acc.d2h();
  jrk.d2h();

  if (dt > 0.0)
  {
    const double h    = dt*0.5;
    const double hinv = 1.0/h;
    const double f1   = 0.5*hinv*hinv;
    const double f2   = 3.0*hinv*f1;

    const double dt2  = dt *dt * (1.0/2.0);
    const double dt3  = dt2*dt * (1.0/3.0);
    const double dt4  = dt3*dt * (1.0/4.0);
    const double dt5  = dt4*dt * (1.0/5.0);

    for (int i = 0; i < n; i++)
    {

      /* compute snp & crk */

      const real4 Am(   acc[i].x - acc0[i].x,     acc[i].y - acc0[i].y,     acc[i].z - acc0[i].z);
      const real4 Jm(h*(jrk[i].x - jrk0[i].x), h*(jrk[i].y - jrk0[i].y), h*(jrk[i].z - jrk0[i].z));
      const real4 Jp(h*(jrk[i].x + jrk0[i].x), h*(jrk[i].y + jrk0[i].y), h*(jrk[i].z + jrk0[i].z));
      real4 snp(f1* Jm.x,         f1* Jm.y,         f1* Jm.z        );
      real4 crk(f2*(Jp.x - Am.x), f2*(Jp.y - Am.y), f2*(Jp.z - Am.z));

      snp.x -= h*crk.x;
      snp.y -= h*crk.y;
      snp.z -= h*crk.z;

      /* correct */

      pos[i].x += dt4*snp.x + dt5*crk.x;
      pos[i].y += dt4*snp.y + dt5*crk.y;
      pos[i].z += dt4*snp.z + dt5*crk.z;

      vel[i].x += dt3*snp.x + dt4*crk.x;
      vel[i].y += dt3*snp.y + dt4*crk.y;
      vel[i].z += dt3*snp.z + dt4*crk.z;
    }
  }

  return timestep(vel, acc, eta, eps2);
}


void integrate(
    dev::context &context,
    std::vector<real4> &hPos,
    std::vector<real4> &hVel,
    const double eta,
    const double eps2,
    const double t_end) {
  dev::kernel compute_forces(context);
  char flags[256];
  sprintf(flags, "-DBLOCKDIM=%d ", BLOCKDIM);
  compute_forces.load_source("compute_forces.cl", "./", flags);
  compute_forces.create("compute_forces");

  const int n = hPos.size();
  assert(hPos.size() == hVel.size());

  dev::memory<real4> pos(context, n), vel(context, n), acc(context, n), jrk(context, n);

  pos.set(hPos);
  vel.set(hVel);

  pos.h2d();
  vel.h2d();

  const double tin = get_time();
  forces(compute_forces, pos, vel, acc, jrk, eps2);
  const double fn = n;
  fprintf(stderr, " mean flop rate in %g sec [%g GFLOP/s]\n", get_time() - tin,
      fn*fn*60/(get_time() - tin)/1e9);

  acc.d2h();
  jrk.d2h();

  double Epot0, Ekin0;
  energy(pos, vel, acc, Ekin0, Epot0);
  const double Etot0 = Epot0 + Ekin0;

  /////////

  double t_global = 0;
  double t0 = 0;
  int iter = 0;
  int ntime = 10;
  double dt = 0;
  double Epot, Ekin, Etot = Etot0;
  while (t_global < t_end) {
    if (iter % ntime == 0) 
      t0 = get_time();

    dt = iterate(compute_forces, pos, vel, acc, jrk, eta, eps2, dt);
    iter++;
    t_global += dt;

    const double Etot_pre = Etot;
    energy(pos, vel, acc, Ekin, Epot);
    Etot = Ekin + Epot;

    if (iter % 1 == 0) {
      const double Etot = Ekin + Epot;
      fprintf(stderr, "iter= %d: t= %g  dt= %g Ekin= %g  Epot= %g  Etot= %g , dE = %g d(dE)= %g \n",
          iter, t_global, dt, Ekin, Epot, Etot, (Etot - Etot0)/std::abs(Etot0),
          (Etot - Etot_pre)/std::abs(Etot_pre)   );
    }

    if (iter % ntime == 0) {
      fprintf(stderr, " mean flop rate in %g sec [%g GFLOP/s]\n", get_time() - t0,
          fn*fn*60/(get_time() - t0)/1e9*ntime);
    }

  }
};

int main(int argc, char *argv[]) {
  dev::context        context;
  std::vector<real4> hPos, hVel;

#ifdef __OPENCL_DEV__
  context.getDeviceCount(CL_DEVICE_TYPE_GPU, 0);
#else
  context.getDeviceCount();
#endif
  context.createQueue(0);

  int nbodies = 131072;
#if 0
  nbodies = 32768;
#endif
  const double R0 = 1;
  const double mp = 1.0/nbodies;
  for (int i = 0; i < nbodies; i++) {
    double xp, yp, zp, s2 = 2*R0;
    double vx, vy, vz;
    while (s2 > R0*R0) {
      xp = (1.0 - 2.0*drand48())*R0;
      yp = (1.0 - 2.0*drand48())*R0;
      zp = (1.0 - 2.0*drand48())*R0;
      s2 = xp*xp + yp*yp + zp*zp;
      vx = drand48() * 0.1;
      vy = drand48() * 0.1;
      vz = drand48() * 0.1;
    } 
    hPos.push_back(real4(xp, yp, zp, mp));
    hVel.push_back(real4(vx, vy, vz, -1));
  }
  const double eps2 = 4.0f/nbodies;
  double eta  = 0.01f;

  if (argc > 1) eta *= atof(argv[1]);
  fprintf(stderr, " eta= %g \n", eta);
  fprintf(stderr, " stargting ... \n");
  const double tend = 1.0;
  integrate(context, hPos, hVel, eta, eps2, tend);

}
