#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cfloat>

#include <sys/time.h>

double rtc(void)
{
  struct timeval Tvalue;
  double etime;
  struct timezone dummy;

  gettimeofday(&Tvalue,&dummy);
  etime =  (double) Tvalue.tv_sec +
    1.e-6*((double) Tvalue.tv_usec);
  return etime;
}

typedef double real;

  __attribute__((vector))
real f(real x) 
{
  real y = 1.0;
  while(1)
  {
    const real e = (y * std::exp(y) - x) / (std::exp(y) + y * std::exp(y));
    y -= e;
    if (std::abs(e) <= DBL_EPSILON) return y;
  }
  return y;
}

template<bool SIMD>
void calc(const int n, const real * x)
{
  printf(" --- \n");
  printf("%.16g\n", x[123]);
  real y[n];

  const double t0 = rtc();

  if (SIMD)
  {
#pragma simd
    for (int i = 0; i < n; i++)
      y[i] = f(x[i]);
  }
  else
  {
#pragma novector
    for (int i = 0; i < n; i++)
      y[i] = f(x[i]);
  }

  const real t = rtc() - t0;
  printf("%.16g %.16g\n", y[123] * exp(y[123]), y[123]);
  printf("%s :: done in  %.6f sec\n", (SIMD ? "SIMD" : "SCALAR"), t);
}

int main(int argc, char * argv[])
{
  int nel = 1048576;
  if (argc > 1) nel = atoi(argv[1]);
  printf("nel= %d\n", nel);

  real x[nel];

  for (int i = 0; i < nel; i++)
    x[i] = drand48();

  calc<false>(nel, x);
  calc<true>(nel, x);
  printf(" --- \n");
}

