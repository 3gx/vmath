#!/bin/sh
ulimit -s unlimited
echo "C++ code, note SIMD works and make code run fast"
icpc --version
./elemental_c
echo "F90 code, note SIMD has no effects on runtime "
icpc --version
./elemental_f
