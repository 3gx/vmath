#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <sys/time.h>
#include <cassert>

typedef double real;
#define VLEN 8

double rtc(void)
{
  struct timeval Tvalue;
  double etime;
  struct timezone dummy;

  gettimeofday(&Tvalue,&dummy);
  etime =  (double) Tvalue.tv_sec +
    1.e-6*((double) Tvalue.tv_usec);
  return etime;
}

/* -- checksum calcualtor -- */

real chksum(const int nx, const int ny, const restrict real * in)
{
  const real (*data)[nx] = (real (*)[nx])in;
  real chksum = 0.0;

#pragma novector
  for (int j = 0; j < ny; j++)
#pragma novector
    for (int i = 0; i < nx; i++)
      chksum += std::abs(data[j][i]);

  return chksum/real(nx*ny);
}

void print_chksum(const char * ver, const real dt, const real chksum)
{
  printf(" %s :: chksum= %.16g   done in %g sec\n", ver, chksum, dt);
}

/* -- cell's microphysics -- */

/* if we check assembly, the array "values" is not promoted to ymm, and accesses are serialzed/strided  instead of coleaseced */
/* see examples this function in calc1 and calc2 below */
  template<int DIM>
  __attribute__((vector))
real cell_physics(const real values[DIM])
{
  real res = 0.0;
  for (int j= 0; j < DIM; j++)
    for (int i= j+1; i < DIM; i++)
    {
      const real df = values[j] - values[i];
      res += df*df;
    }
  return std::sqrt(res);
}

/* this routine overrides compiler behaviour: I manually promote array "values" to ymm  and let compiler to access it in coalseced way */
/* this produces substantial gain in performance! */
/* see examples this function in calc3 and calc4 below */
template<int DIM>
__attribute__(( vector(uniform(res,values),linear(laneIdx:1)) ))
void cell_physics(const int laneIdx, real res[VLEN], const real values[DIM][VLEN])
{
  real rest = 0.0;
  for (int j= 0; j < DIM; j++)
    for (int i= j+1; i < DIM; i++)
    {
      const real df = values[j][laneIdx] - values[i][laneIdx];
      rest += df*df;
    }
  res[laneIdx] = std::sqrt(rest);
}

/* -- different imlementations -- */ 

  template<int M>
void calc1(const int nx, const int ny, const restrict real * in, restrict real * out)
{
  const real (*data)[nx] = (real (*)[nx])in;
  real       (*res )[nx] = (real (*)[nx])out;

  const double t0 = rtc();

  for (int j = 0; j < ny; j++)
    for (int i = 0; i < nx; i++)
    {
      real sloc[M];
      for (int k = 0; k < M; k++)
        sloc[k] = data[j][std::min(i+k,nx-1)];

      res[j][i] = cell_physics<M>(sloc);
    }
  const double t1 = rtc();
  print_chksum("version 1 ", t1-t0, chksum(nx,ny,out));
}

  template<int M>
void calc2(const int nx, const int ny, const restrict real * in, restrict real * out)
{
  const real (*data)[nx] = (real (*)[nx])in;
  real       (*res )[nx] = (real (*)[nx])out;

  const double t0 = rtc();

  for (int j = 0; j < ny; j++)
#pragma simd
    for (int i = 0; i < nx; i++)
    {
      real sloc[M];
      for (int k = 0; k < M; k++)
        sloc[k] = data[j][std::min(i+k,nx-1)];

      res[j][i] = cell_physics<M>(sloc);
    }
  const double t1 = rtc();
  print_chksum("version 2 ", t1-t0, chksum(nx,ny,out));
}
  
  template<int M, bool USEIF>
void calc3(const int nx, const int ny, const restrict real * in, restrict real * out)
{
  const real (*data)[nx] = (real (*)[nx])in;
  real       (*res )[nx] = (real (*)[nx])out;

  const double t0 = rtc();

  real sloc[M][VLEN], rest[VLEN];

  for (int j = 0; j < ny; j++)
    for (int ib = 0; ib < nx; ib += VLEN)
#pragma simd
      for (int laneIdx = 0; laneIdx < VLEN; laneIdx++)
      {
        const int i = ib + laneIdx;
        /* i would like to use *if* statement, BUT
         * this tremendously impacts performance, why? */
        /* why compiler can't do what I've done in calc4 ?!? */

        if (USEIF)
          if (i >= nx) continue;

        for (int k = 0; k < M; k++)
          sloc[k][laneIdx] = data[j][std::min(i+k,nx-1)];

        cell_physics<M>(laneIdx, rest, sloc);
        res[j][i] = rest[laneIdx];
      }
  const double t1 = rtc();
  print_chksum(USEIF ? "version 3b" : "version 3a", t1-t0, chksum(nx,ny,out));
}
  
  template<int M>
void calc4(const int nx, const int ny, const restrict real * in, restrict real * out)
{
  const real (*data)[nx] = (real (*)[nx])in;
  real       (*res )[nx] = (real (*)[nx])out;

  const double t0 = rtc();

  real sloc[M][VLEN], rest[VLEN];

  const int nxV = nx & (~(VLEN-1));

  for (int j = 0; j < ny; j++)
  {
    for (int ib = 0; ib < nxV; ib += VLEN)
#pragma simd
      for (int laneIdx = 0; laneIdx < VLEN; laneIdx++)
      {
        const int i = ib + laneIdx;

        for (int k = 0; k < M; k++)
          sloc[k][laneIdx] = data[j][std::min(i+k,nx-1)];

        cell_physics<M>(laneIdx, rest, sloc);
        res[j][i] = rest[laneIdx];
      }

    for (int i = nxV; i < nx; i++)
    {
      real sloc[M];

      for (int k = 0; k < M; k++)
        sloc[k] = data[j][std::min(i+k,nx-1)];

      res[j][i] = cell_physics<M>(sloc);
    }
  }
  const double t1 = rtc();
  print_chksum("version 4 ", t1-t0, chksum(nx,ny,out));
}


#include <sys/time.h>


int main(int argc, char * argv[])
{
  int nx = 429;
  int ny = 330;
  if (argc > 1) nx = atoi(argv[1]);
  if (argc > 2) ny = atoi(argv[2]);
#if 0
  nx = (nx & (~(VLEN-1))) + VLEN;
#endif

  printf("nx= %d  ny= %d \n", nx,ny);

  real data[ny][nx], res[ny][nx];

  for (int j = 0; j < ny; j++)
    for (int i = 0; i < nx; i++)
      data[j][i] = drand48();

  const int M = 13;

  printf(" -- \n");

  calc1<M>(nx,ny,&data[0][0], &res[0][0]);

  calc2<M>(nx,ny,&data[0][0], &res[0][0]);

  calc3<M,false>(nx,ny,&data[0][0], &res[0][0]);

  calc3<M,true>(nx,ny,&data[0][0], &res[0][0]);
  
  calc4<M>(nx,ny,&data[0][0], &res[0][0]);

  printf(" -- \n");

  return 0;
}
