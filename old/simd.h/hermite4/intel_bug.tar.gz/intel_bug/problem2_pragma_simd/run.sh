#!/bin/sh
ulimit -s unlimited
icpc --version
./vectorize
