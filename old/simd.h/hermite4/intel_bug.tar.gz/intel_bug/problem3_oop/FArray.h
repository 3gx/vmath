#pragma once

#include <cstdio>
#include <cstdlib>
#include <cassert>

template<typename T>
struct FArray3D
{
  private:
    const int _nx,_ny,_nz;
    const int _xmin;
    const int _ymin;
    const int _zmin;
    restrict T *_data;

  public:

    FArray3D() : _nx(0), _ny(0), _nz(0), _xmin(0), _ymin(0), _zmin(0), _data(NULL) {}
    FArray3D(T *data, const int nx, const int ny, const int nz, const int xmin = 0, const int ymin = 0, const int zmin = 0) :
     _nx(nx), _ny(ny), _nz(nz), _xmin(xmin), _ymin(ymin), _zmin(zmin), _data(data - zmin*nx*ny - ymin*nx - xmin) {}

    const T& operator()(const int i, const int j, const int k) const { return _data[i + _nx*(j + _ny*k)]; }
    T& operator()(const int i, const int j, const int k) { return _data[i + _nx*(j + _ny*k)]; }
    
    operator T*() {return *_data;}

    int xmin() const { return  _xmin; }
    int ymin() const { return  _ymin; }
    int zmin() const { return  _zmin; }
    int nx() const { return _nx; }
    int ny() const { return _ny; }
    int nz() const { return _nz; }
};

template<typename T>
struct FArray2D
{
  private:
    int _nx,_ny;
    int _xmin;
    int _ymin;
    restrict T *_data;

  public:

    FArray2D() : _data(NULL) {}
    FArray2D(T *data, const int nx, const int ny, const int xmin = 0, const int ymin = 0) :
     _nx(nx), _ny(ny), _xmin(xmin), _ymin(ymin), _data(data - ymin*nx - xmin) {}


    const T& operator()(const int i, const int j) const { return _data[i + j*_nx]; }
    T& operator()(const int i, const int j) { return _data[i + j*_nx]; }
    
    operator T*() {return *_data;}

    int xmin() const { return  _xmin; }
    int ymin() const { return  _ymin; }
    int nx() const { return _nx; }
    int ny() const { return _ny; }
};

template<typename T, const int NX>
struct FArray1D
{
  private:
    int _xmin;
    T *_data;

  public:

    FArray1D(
        const T  *data = NULL,
        const int xmin = 0) : _xmin(xmin)
  {
    set_data(data);
  }

    void set_data(const T *data)
    {
      _data = (T*)(data - _xmin);
    }

    const T& operator()(const int i) const { return _data[i]; }
    T& operator()(const int i) { return _data[i]; }

    operator T*() {return _data;}

    int xmin() const { return _xmin; }
};

