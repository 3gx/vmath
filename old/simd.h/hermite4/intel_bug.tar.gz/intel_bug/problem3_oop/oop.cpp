#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <sys/time.h>
#include <cassert>
double rtc(void)
{
  struct timeval Tvalue;
  double etime;
  struct timezone dummy;

  gettimeofday(&Tvalue,&dummy);
  etime =  (double) Tvalue.tv_sec +
    1.e-6*((double) Tvalue.tv_usec);
  return etime;
}

#include "FArray.h"

typedef double real;

extern real *common_mp_data_in_;
extern real *common_mp_data_out_;
extern int   common_mp_nx_;
extern int   common_mp_ny_;

#define _data_in common_mp_data_in_
#define _data_out common_mp_data_out_
#define _nx common_mp_nx_
#define _ny common_mp_ny_
#define _nz common_mp_nz_

#define VLEN 8

#define KS 5

  template<int DIM>
__attribute__(( vector(uniform(res,values),linear(laneIdx:1)) ))
void cell_physics(const int laneIdx, real res[VLEN], const real values[DIM][VLEN])
{
  real rest = 0.0;
  for (int j= 0; j < DIM; j++)
    for (int i= j+1; i < DIM; i++)
    {
      const real df = values[j][laneIdx] - values[i][laneIdx];
      rest += df*df;
    }
  res[laneIdx] = std::sqrt(rest);
}


struct Lib
{
  FArray3D<real> data_out;
  const FArray3D<real> data_in;
  const int nx, ny;

  Lib() :
    data_out(FArray3D<real>(_data_out, _nx, _ny, KS)),
    data_in (FArray3D<real>(_data_in, _nx, _ny,  KS)),
    nx(_nx), ny(_ny) {}

  real chksum(const FArray3D<real> &data)
  {
    real chksum = 0.0;
    for (int k = 0; k < data.nz(); k++)
      for (int j = 0; j < data.ny(); j++)
        for (int i = 0; i < data.nx(); i++)
          chksum += std::abs(data(i,j,k));
    return chksum/real(data.nx()*data.ny()*data.nz());
  }

  template<bool USEIF>
    void func1A()
    {
      real sloc[KS][VLEN], rest[VLEN];

#if 0  /* if set to 0, compiler fails to vectorize */
      const FArray3D<real> data_in = this->data_in;
#endif
#if 0  /* if set to 0, compiler generates slow code when result is written to data_out */
      /* the code includes full address computation, why? */
      FArray3D<real> data_out = this->data_out;
#endif

      const double t0 = rtc();
      asm("#mybeg1a");
      for (int j = 0; j < ny; j++)
        for (int ib = 0; ib < nx; ib += VLEN)
#pragma simd
          for (int laneIdx = 0; laneIdx < VLEN; laneIdx++)
          {
            const int i = ib + laneIdx;

            /* i would like to use *if* statement, BUT
             * this tremendously impacts performance, why? */
            /* why compiler can't do what I've done in calc4 ?!? */

            if (USEIF)
              if (i >= nx) continue;

#pragma novector
            for (int k = 0; k < KS; k++)
              sloc[k][laneIdx] = data_in(i,j,k);

            cell_physics<KS>(laneIdx, rest, sloc);
            for (int k = 0; k < KS; k++)
              data_out(i,j,k) = rest[laneIdx];
          }
      asm("#myend1a");

      const double t1 = rtc();
      printf(" 1a: %s IF : chksum= %.16g   done in %.5g sec \n", USEIF ? "with" : "w/o ", chksum(this->data_out), t1 - t0);
    }

  template<bool USEIF>
    void func1B()
    {
      real sloc[KS][VLEN], rest[VLEN];

#if 1  /* if set to 0, compiler fails to vectorize */
      const FArray3D<real> data_in = this->data_in;
#endif
#if 0  /* if set to 0, compiler generates slow code when result is written to data_out */
      /* the code includes full address computation, why? */
      FArray3D<real> data_out = this->data_out;
#endif

      const double t0 = rtc();
      asm("#mybeg1b");
      for (int j = 0; j < ny; j++)
        for (int ib = 0; ib < nx; ib += VLEN)
#pragma simd
          for (int laneIdx = 0; laneIdx < VLEN; laneIdx++)
          {
            const int i = ib + laneIdx;

            /* i would like to use *if* statement, BUT
             * this tremendously impacts performance, why? */
            /* why compiler can't do what I've done in calc4 ?!? */

            if (USEIF)
              if (i >= nx) continue;

#pragma novector
            for (int k = 0; k < KS; k++)
              sloc[k][laneIdx] = data_in(i,j,k);

            cell_physics<KS>(laneIdx, rest, sloc);
            for (int k = 0; k < KS; k++)
              data_out(i,j,k) = rest[laneIdx];
          }
      asm("#myend1b");

      const double t1 = rtc();
      printf(" 1b: %s IF : chksum= %.16g   done in %.5g sec \n", USEIF ? "with" : "w/o ", chksum(this->data_out), t1 - t0);
    }
  
  template<bool USEIF>
    void func1C()
    {
      real sloc[KS][VLEN], rest[VLEN];

#if 1  /* if set to 0, compiler fails to vectorize */
      const FArray3D<real> data_in = this->data_in;
#endif
#if 1  /* if set to 0, compiler generates slow code when result is written to data_out */
      /* the code includes full address computation, why? */
      FArray3D<real> data_out = this->data_out;
#endif

      const double t0 = rtc();
      asm("#mybeg1c");
      for (int j = 0; j < ny; j++)
        for (int ib = 0; ib < nx; ib += VLEN)
#pragma simd
          for (int laneIdx = 0; laneIdx < VLEN; laneIdx++)
          {
            const int i = ib + laneIdx;

            /* i would like to use *if* statement, BUT
             * this tremendously impacts performance, why? */
            /* why compiler can't do what I've done in calc4 ?!? */

            if (USEIF)
              if (i >= nx) continue;

#pragma novector
            for (int k = 0; k < KS; k++)
              sloc[k][laneIdx] = data_in(i,j,k);

            cell_physics<KS>(laneIdx, rest, sloc);
            for (int k = 0; k < KS; k++)
              data_out(i,j,k) = rest[laneIdx];
          }
      asm("#myend1c");

      const double t1 = rtc();
      printf(" 1c: %s IF : chksum= %.16g   done in %.5g sec \n", USEIF ? "with" : "w/o ", chksum(this->data_out), t1 - t0);
    }
  
  template<bool USEIF>
    void func2()
    {
      real sloc[KS][VLEN], rest[VLEN];

      /* comiler vectorizes this function quite fine */

      const real (*din)[ny][nx] = (real(*)[ny][nx]) _data_in;
            real (*dout)[ny][nx] = (real(*)[ny][nx])_data_out;

      const double t0 = rtc();
      asm("#mybeg2");
      for (int j = 0; j < ny; j++)
        for (int ib = 0; ib < nx; ib += VLEN)
#pragma simd
          for (int laneIdx = 0; laneIdx < VLEN; laneIdx++)
          {
            const int i = ib + laneIdx;

            /* i would like to use *if* statement, BUT
             * this tremendously impacts performance, why? */
            /* why compiler can't do what I've done in calc4 ?!? */

            if (USEIF)
              if (i >= nx) continue;

            for (int k = 0; k < KS; k++)
              sloc[k][laneIdx] = din[k][j][i];

            cell_physics<KS>(laneIdx, rest, sloc);
            for (int k = 0; k < KS; k++)
              dout[k][j][i] = rest[laneIdx];
          }
      asm("#myend2");

      const double t1 = rtc();
      printf(" 2 : %s IF : chksum= %.16g   done in %.5g sec \n", USEIF ? "with" : "w/o ", chksum(this->data_out), t1 - t0);
    }
  
  template<bool USEIF>
    void func3A()
    {
      real sloc[KS][VLEN], rest[VLEN];

      const double t0 = rtc();
      asm("#mybeg3a");
      for (int j = 0; j < ny; j++)
        for (int ib = 0; ib < nx; ib += VLEN)
#pragma simd
          for (int laneIdx = 0; laneIdx < VLEN; laneIdx++)
          {
            const int i = ib + laneIdx;

            /* i would like to use *if* statement, BUT
             * this tremendously impacts performance, why? */
            /* why compiler can't do what I've done in calc4 ?!? */

            if (USEIF)
              if (i >= nx) continue;

            for (int k = 0; k < KS; k++)
              sloc[k][laneIdx] = _data_in[i+nx*(j+ny*k)];

            cell_physics<KS>(laneIdx, rest, sloc);
            for (int k = 0; k < KS; k++)
              _data_out[i+nx*(j+ny*k)] = rest[laneIdx];
          }
      asm("#myend3a");

      const double t1 = rtc();
      printf(" 3a: %s IF : chksum= %.16g   done in %.5g sec \n", USEIF ? "with" : "w/o ", chksum(this->data_out), t1 - t0);
    }
  template<bool USEIF>
    void func3B()
    {
      real sloc[KS][VLEN], rest[VLEN];

      /* notice we redefined, nx & ny, and compiler was able to vectorize!! */
      const int nx = this->nx;
      const int ny = this->ny;

      const double t0 = rtc();
      asm("#mybeg3b");
      for (int j = 0; j < ny; j++)
        for (int ib = 0; ib < nx; ib += VLEN)
#pragma simd
          for (int laneIdx = 0; laneIdx < VLEN; laneIdx++)
          {
            const int i = ib + laneIdx;

            /* i would like to use *if* statement, BUT
             * this tremendously impacts performance, why? */
            /* why compiler can't do what I've done in calc4 ?!? */

            if (USEIF)
              if (i >= nx) continue;

            for (int k = 0; k < KS; k++)
              sloc[k][laneIdx] = _data_in[i+nx*(j+ny*k)];

            cell_physics<KS>(laneIdx, rest, sloc);
            for (int k = 0; k < KS; k++)
              _data_out[i+nx*(j+ny*k)] = rest[laneIdx];
          }
      asm("#myend3b");

      const double t1 = rtc();
      printf(" 3b: %s IF : chksum= %.16g   done in %.5g sec \n", USEIF ? "with" : "w/o ", chksum(this->data_out), t1 - t0);
    }
};


Lib* lib = NULL;

extern "C"
{

  void lib_open_()
  {
    assert(lib == NULL);
    lib = new Lib();
  }

  void lib_close_()
  {
    assert(lib != NULL);
    delete lib;
    lib = NULL;
  }

  void lib_func1_()
  {
    assert(lib != NULL);
    const bool flag = false;
    lib->func1A<flag>();
    lib->func1B<flag>();
    lib->func1C<flag>();
    printf("---\n");

    lib->func2 <flag>();
    printf("---\n");

    lib->func3A<flag>();
    lib->func3B<flag>();
    printf("---\n");
  }
  
  void lib_func2_()
  {
    assert(lib != NULL);
    const bool flag = true;
    lib->func1A<flag>();
    lib->func1B<flag>();
    lib->func1C<flag>();
    printf("---\n");

    lib->func2 <flag>();
    printf("---\n");

    lib->func3A<flag>();
    lib->func3B<flag>();
    printf("---\n");
  }
  
}


