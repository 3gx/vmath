#!/bin/sh
ulimit -s unlimited
ifort --version
icpc --version
./oop
